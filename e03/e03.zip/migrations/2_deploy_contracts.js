var Floken = artifacts.require("Floken");
module.exports = function ( deployer ) {
    deployer.deploy( Floken );
};
